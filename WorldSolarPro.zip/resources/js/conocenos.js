var carouselHeader = document.querySelector('.carousel--header');
var carousel = new Carousel(carouselHeader, true, false, [1,1,1,1,1]);

var carouselQuienes = document.querySelector('.carousel--quienes-somos');
var carousel = new Carousel(carouselQuienes, true, false, [1,1,1,1,1]);

var carouselAliados = document.querySelector('.carousel--aliados');
var carousel = new Carousel(carouselAliados, true, false, [1, 1, 1, 1, 1])